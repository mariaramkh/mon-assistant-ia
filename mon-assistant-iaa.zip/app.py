import streamlit as st

st.switch_page("pages/0_Accueil.py")